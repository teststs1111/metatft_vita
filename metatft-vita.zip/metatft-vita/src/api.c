#include <psp2/net/net.h>
#include <psp2/net/netctl.h>
#include <psp2/net/http.h>
#include <psp2/sysmodule.h>
#include <psp2/kernel/threadmgr.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "api.h"
#include "config.h"
#include "cJSON.h"

#define NET_INIT_SIZE (1 * 1024 * 1024)
#define READ_CHUNK    4096

static int s_net_inited = 0;
static void *s_net_mem = NULL;
static int s_http_tmpl_id = -1;

int api_init(void) {
    int ret;

    ret = sceSysmoduleLoadModule(SCE_SYSMODULE_NET);
    if (ret < 0) return ret;

    SceNetInitParam net_param;
    s_net_mem = malloc(NET_INIT_SIZE);
    if (!s_net_mem) return -1;
    net_param.memory = s_net_mem;
    net_param.size = NET_INIT_SIZE;
    net_param.flags = 0;

    ret = sceNetInit(&net_param);
    if (ret < 0 && ret != (int)0x80410100 /* already inited */) {
        free(s_net_mem);
        s_net_mem = NULL;
        return ret;
    }

    ret = sceNetCtlInit();
    if (ret < 0 && ret != (int)0x80412102 /* already inited */) {
        return ret;
    }

    ret = sceSysmoduleLoadModule(SCE_SYSMODULE_HTTPS);
    if (ret < 0) return ret;

    ret = sceHttpInit(1 * 1024 * 1024);
    if (ret < 0) return ret;

    s_http_tmpl_id = sceHttpCreateTemplate(
        "MetaTFT-Vita/0.1", SCE_HTTP_VERSION_1_1, SCE_TRUE);
    if (s_http_tmpl_id < 0) return s_http_tmpl_id;

    s_net_inited = 1;
    return 0;
}

void api_shutdown(void) {
    if (s_http_tmpl_id >= 0) {
        sceHttpDeleteTemplate(s_http_tmpl_id);
        s_http_tmpl_id = -1;
    }
    sceHttpTerm();
    sceSysmoduleUnloadModule(SCE_SYSMODULE_HTTPS);
    if (s_net_inited) {
        sceNetCtlTerm();
        sceNetTerm();
        s_net_inited = 0;
    }
    if (s_net_mem) {
        free(s_net_mem);
        s_net_mem = NULL;
    }
}

// Reads the whole HTTP response body into a malloc'd, NUL-terminated buffer.
// Caller must free() the result. Returns NULL on failure.
static char *http_get_body(const char *url, char *err_msg, int err_len) {
    int conn_id = -1, req_id = -1, ret;
    char *body = NULL;
    size_t body_cap = 0, body_len = 0;
    int status_code = 0;

    conn_id = sceHttpCreateConnectionWithURL(s_http_tmpl_id, url, SCE_FALSE);
    if (conn_id < 0) {
        snprintf(err_msg, err_len, "connect create failed: 0x%08X", conn_id);
        goto fail;
    }

    req_id = sceHttpCreateRequestWithURL(
        conn_id, SCE_HTTP_METHOD_GET, url, 0);
    if (req_id < 0) {
        snprintf(err_msg, err_len, "request create failed: 0x%08X", req_id);
        goto fail;
    }

    if (strlen(API_KEY_VALUE) > 0 &&
        strcmp(API_KEY_VALUE, "PUT_YOUR_KEY_HERE") != 0) {
        sceHttpAddRequestHeader(
            req_id, API_KEY_HEADER, API_KEY_VALUE,
            SCE_HTTP_HEADER_ADD);
    }

    ret = sceHttpSendRequest(req_id, NULL, 0);
    if (ret < 0) {
        snprintf(err_msg, err_len, "send failed: 0x%08X (check Wi-Fi)", ret);
        goto fail;
    }

    sceHttpGetStatusCode(req_id, &status_code);
    if (status_code < 200 || status_code >= 300) {
        snprintf(err_msg, err_len, "HTTP status %d", status_code);
        goto fail;
    }

    body_cap = READ_CHUNK * 4;
    body = malloc(body_cap);
    if (!body) {
        snprintf(err_msg, err_len, "out of memory");
        goto fail;
    }

    unsigned char chunk[READ_CHUNK];
    for (;;) {
        int n = sceHttpReadData(req_id, chunk, READ_CHUNK);
        if (n < 0) {
            snprintf(err_msg, err_len, "read failed: 0x%08X", n);
            goto fail;
        }
        if (n == 0) break; // EOF

        if (body_len + (size_t)n + 1 > body_cap) {
            body_cap *= 2;
            char *nbody = realloc(body, body_cap);
            if (!nbody) {
                snprintf(err_msg, err_len, "out of memory");
                goto fail;
            }
            body = nbody;
        }
        memcpy(body + body_len, chunk, n);
        body_len += n;
    }
    body[body_len] = '\0';

    sceHttpDeleteRequest(req_id);
    sceHttpDeleteConnection(conn_id);
    return body;

fail:
    if (body) free(body);
    if (req_id >= 0) sceHttpDeleteRequest(req_id);
    if (conn_id >= 0) sceHttpDeleteConnection(conn_id);
    return NULL;
}

// Adjust this to match whatever JSON shape your chosen data source
// actually returns (see include/config.h for the expected shape).
static int parse_comps_json(const char *json_text, CompList *out,
                             char *err_msg, int err_len) {
    cJSON *root = cJSON_Parse(json_text);
    if (!root) {
        snprintf(err_msg, err_len, "JSON parse error near: %.40s",
                  cJSON_GetErrorPtr() ? cJSON_GetErrorPtr() : "?");
        return -1;
    }

    // Some APIs wrap the array in {"comps": [...]} or {"data": [...]}.
    cJSON *arr = root;
    if (!cJSON_IsArray(root)) {
        arr = cJSON_GetObjectItemCaseSensitive(root, "comps");
        if (!arr || !cJSON_IsArray(arr))
            arr = cJSON_GetObjectItemCaseSensitive(root, "data");
    }
    if (!arr || !cJSON_IsArray(arr)) {
        snprintf(err_msg, err_len, "unexpected JSON shape (no array found)");
        cJSON_Delete(root);
        return -1;
    }

    out->count = 0;
    cJSON *item;
    cJSON_ArrayForEach(item, arr) {
        if (out->count >= MAX_COMPS) break;
        CompEntry *e = &out->comps[out->count];
        memset(e, 0, sizeof(*e));

        cJSON *name = cJSON_GetObjectItemCaseSensitive(item, "name");
        if (cJSON_IsString(name) && name->valuestring)
            snprintf(e->name, MAX_NAME_LEN, "%s", name->valuestring);
        else
            snprintf(e->name, MAX_NAME_LEN, "(unnamed comp)");

        cJSON *wr = cJSON_GetObjectItemCaseSensitive(item, "winrate");
        if (cJSON_IsNumber(wr)) e->winrate = (float)wr->valuedouble;

        cJSON *pr = cJSON_GetObjectItemCaseSensitive(item, "pickrate");
        if (cJSON_IsNumber(pr)) e->pickrate = (float)pr->valuedouble;

        cJSON *ap = cJSON_GetObjectItemCaseSensitive(item, "avg_place");
        if (cJSON_IsNumber(ap)) e->avg_place = (float)ap->valuedouble;

        cJSON *traits = cJSON_GetObjectItemCaseSensitive(item, "traits");
        if (cJSON_IsArray(traits)) {
            cJSON *t;
            cJSON_ArrayForEach(t, traits) {
                if (e->trait_count >= MAX_TRAITS) break;
                if (cJSON_IsString(t) && t->valuestring) {
                    snprintf(e->traits[e->trait_count], MAX_TRAIT_LEN,
                             "%s", t->valuestring);
                    e->trait_count++;
                }
            }
        }

        out->count++;
    }

    cJSON_Delete(root);
    return 0;
}

int api_fetch_comps(CompList *out, char *err_msg, int err_msg_len) {
    if (!s_net_inited) {
        snprintf(err_msg, err_msg_len, "network not initialized");
        return -1;
    }

    char *body = http_get_body(API_BASE_URL, err_msg, err_msg_len);
    if (!body) return -1;

    int ret = parse_comps_json(body, out, err_msg, err_msg_len);
    free(body);
    return ret;
}
