#include <psp2/ctrl.h>
#include <psp2/kernel/threadmgr.h>
#include <psp2/kernel/processmgr.h>
#include <vita2d.h>
#include <stdio.h>
#include <string.h>

#include "api.h"
#include "config.h"

#define SCREEN_W 960
#define SCREEN_H 544

#define COLOR_BG      RGBA8(0x12, 0x12, 0x18, 0xFF)
#define COLOR_HEADER  RGBA8(0x2a, 0x2a, 0x3a, 0xFF)
#define COLOR_TEXT    RGBA8(0xEE, 0xEE, 0xEE, 0xFF)
#define COLOR_DIM     RGBA8(0x99, 0x99, 0xA5, 0xFF)
#define COLOR_ACCENT  RGBA8(0x5A, 0xC8, 0xFA, 0xFF)
#define COLOR_ROW_SEL RGBA8(0x33, 0x44, 0x66, 0xFF)
#define COLOR_ERROR   RGBA8(0xFF, 0x6B, 0x6B, 0xFF)

typedef enum {
    STATE_LOADING,
    STATE_LIST,
    STATE_DETAIL,
    STATE_ERROR
} AppState;

static AppState g_state = STATE_LOADING;
static CompList g_comps;
static int g_selected = 0;
static int g_scroll_top = 0;
static char g_err_msg[128] = {0};

#define ROWS_VISIBLE 7
#define ROW_HEIGHT   58
#define LIST_TOP     80

static void draw_header(vita2d_pgf *font, const char *subtitle) {
    vita2d_draw_rectangle(0, 0, SCREEN_W, 56, COLOR_HEADER);
    vita2d_pgf_draw_text(font, 20, 36, COLOR_TEXT, 1.2f, APP_TITLE);
    if (subtitle) {
        vita2d_pgf_draw_text(font, 400, 36, COLOR_DIM, 0.9f, subtitle);
    }
}

static void draw_list(vita2d_pgf *font) {
    draw_header(font, "\xE2\x86\x91\xE2\x86\x93 select   X details   SELECT refresh");

    if (g_comps.count == 0) {
        vita2d_pgf_draw_text(font, 20, LIST_TOP + 30, COLOR_DIM, 1.0f,
                              "No comps loaded.");
        return;
    }

    if (g_selected < g_scroll_top) g_scroll_top = g_selected;
    if (g_selected >= g_scroll_top + ROWS_VISIBLE)
        g_scroll_top = g_selected - ROWS_VISIBLE + 1;

    int end = g_scroll_top + ROWS_VISIBLE;
    if (end > g_comps.count) end = g_comps.count;

    for (int i = g_scroll_top; i < end; i++) {
        int row = i - g_scroll_top;
        int y = LIST_TOP + row * ROW_HEIGHT;
        CompEntry *c = &g_comps.comps[i];

        if (i == g_selected) {
            vita2d_draw_rectangle(10, y, SCREEN_W - 20, ROW_HEIGHT - 6,
                                   COLOR_ROW_SEL);
        }

        vita2d_pgf_draw_text(font, 24, y + 26, COLOR_TEXT, 1.0f, c->name);

        char stats[96];
        snprintf(stats, sizeof(stats), "WR %.1f%%   PR %.1f%%   Avg %.2f",
                  c->winrate, c->pickrate, c->avg_place);
        vita2d_pgf_draw_text(font, 24, y + 46, COLOR_ACCENT, 0.85f, stats);
    }
}

static void draw_detail(vita2d_pgf *font) {
    draw_header(font, "O back");
    if (g_selected < 0 || g_selected >= g_comps.count) return;
    CompEntry *c = &g_comps.comps[g_selected];

    vita2d_pgf_draw_text(font, 24, 100, COLOR_TEXT, 1.3f, c->name);

    char line[128];
    snprintf(line, sizeof(line), "Win rate:   %.1f%%", c->winrate);
    vita2d_pgf_draw_text(font, 24, 150, COLOR_TEXT, 1.0f, line);
    snprintf(line, sizeof(line), "Pick rate:  %.1f%%", c->pickrate);
    vita2d_pgf_draw_text(font, 24, 175, COLOR_TEXT, 1.0f, line);
    snprintf(line, sizeof(line), "Avg place:  %.2f", c->avg_place);
    vita2d_pgf_draw_text(font, 24, 200, COLOR_TEXT, 1.0f, line);

    vita2d_pgf_draw_text(font, 24, 240, COLOR_DIM, 1.0f, "Traits:");
    for (int i = 0; i < c->trait_count; i++) {
        vita2d_pgf_draw_text(font, 40, 265 + i * 25, COLOR_ACCENT, 0.95f,
                              c->traits[i]);
    }
}

static void draw_error(vita2d_pgf *font) {
    draw_header(font, "SELECT retry");
    vita2d_pgf_draw_text(font, 24, 120, COLOR_ERROR, 1.1f,
                          "Failed to load comps:");
    vita2d_pgf_draw_text(font, 24, 150, COLOR_TEXT, 0.9f, g_err_msg);
    vita2d_pgf_draw_text(font, 24, 200, COLOR_DIM, 0.85f,
                          "Check config.h has a valid API_BASE_URL / key,");
    vita2d_pgf_draw_text(font, 24, 220, COLOR_DIM, 0.85f,
                          "and that Wi-Fi is connected.");
}

static void do_fetch(void) {
    g_state = STATE_LOADING;
    int ret = api_fetch_comps(&g_comps, g_err_msg, sizeof(g_err_msg));
    if (ret != 0) {
        g_state = STATE_ERROR;
    } else {
        g_selected = 0;
        g_scroll_top = 0;
        g_state = STATE_LIST;
    }
}

int main(int argc, char *argv[]) {
    vita2d_init();
    vita2d_set_clear_color(COLOR_BG);
    vita2d_pgf *font = vita2d_load_default_pgf();

    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);

    if (api_init() != 0) {
        snprintf(g_err_msg, sizeof(g_err_msg), "network init failed");
        g_state = STATE_ERROR;
    } else {
        do_fetch();
    }

    SceCtrlData pad, prev_pad;
    memset(&prev_pad, 0, sizeof(prev_pad));

    int running = 1;
    while (running) {
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned int pressed = pad.buttons & ~prev_pad.buttons;

        if (pressed & SCE_CTRL_START) {
            running = 0;
        }

        switch (g_state) {
        case STATE_LIST:
            if (g_comps.count > 0) {
                if (pressed & SCE_CTRL_DOWN) {
                    g_selected = (g_selected + 1) % g_comps.count;
                }
                if (pressed & SCE_CTRL_UP) {
                    g_selected = (g_selected - 1 + g_comps.count) % g_comps.count;
                }
                if (pressed & SCE_CTRL_CROSS) {
                    g_state = STATE_DETAIL;
                }
            }
            if (pressed & SCE_CTRL_SELECT) {
                do_fetch();
            }
            break;

        case STATE_DETAIL:
            if (pressed & SCE_CTRL_CIRCLE) {
                g_state = STATE_LIST;
            }
            break;

        case STATE_ERROR:
            if (pressed & SCE_CTRL_SELECT) {
                do_fetch();
            }
            break;

        case STATE_LOADING:
        default:
            break;
        }

        vita2d_start_drawing();
        vita2d_clear_screen();

        switch (g_state) {
        case STATE_LOADING:
            draw_header(font, NULL);
            vita2d_pgf_draw_text(font, 24, 120, COLOR_TEXT, 1.0f,
                                  "Loading comps...");
            break;
        case STATE_LIST:
            draw_list(font);
            break;
        case STATE_DETAIL:
            draw_detail(font);
            break;
        case STATE_ERROR:
            draw_error(font);
            break;
        }

        vita2d_end_drawing();
        vita2d_swap_buffers();

        prev_pad = pad;
    }

    api_shutdown();
    vita2d_free_pgf(font);
    vita2d_fini();
    sceKernelExitProcess(0);
    return 0;
}
