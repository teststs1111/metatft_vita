#ifndef CONFIG_H
#define CONFIG_H

// ---------------------------------------------------------------------
// MetaTFT has no official public API, so this app talks to whatever
// JSON data source you point it at. Two realistic options:
//
//  1) A third-party proxy/scraper API that already returns MetaTFT-style
//     JSON (comp name, win rate, pick rate, items, traits...).
//     Fill in API_BASE_URL and API_KEY_HEADER/API_KEY_VALUE below.
//
//  2) Your own small backend (e.g. a Cloudflare Worker or Vercel
//     function you control) that fetches/caches MetaTFT data server
//     side and re-serves it as simple JSON. This is the safer option
//     re: rate limits / ToS, since the Vita never talks to MetaTFT
//     directly and you control caching.
//
// Whichever you use, the app expects a JSON array of objects shaped like:
// [
//   {
//     "name": "Comp Name",
//     "winrate": 47.2,
//     "pickrate": 3.1,
//     "avg_place": 4.12,
//     "traits": ["Trait A", "Trait B"]
//   },
//   ...
// ]
// Adjust the field names in src/api.c's parse function to match
// whatever your chosen source actually returns.
// ---------------------------------------------------------------------

#define API_BASE_URL   "https://example.com/api/comps"
#define API_KEY_HEADER "X-API-Key"
#define API_KEY_VALUE  "PUT_YOUR_KEY_HERE"

#define APP_TITLE      "MetaTFT Vita"

#endif // CONFIG_H
