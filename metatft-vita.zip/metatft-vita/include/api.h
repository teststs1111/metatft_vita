#ifndef API_H
#define API_H

#define MAX_COMPS      64
#define MAX_NAME_LEN   96
#define MAX_TRAITS     6
#define MAX_TRAIT_LEN  32

typedef struct {
    char name[MAX_NAME_LEN];
    float winrate;
    float pickrate;
    float avg_place;
    char traits[MAX_TRAITS][MAX_TRAIT_LEN];
    int trait_count;
} CompEntry;

typedef struct {
    CompEntry comps[MAX_COMPS];
    int count;
} CompList;

// Initializes SceHttp/SceSsl. Call once at startup.
int api_init(void);
void api_shutdown(void);

// Fetches API_BASE_URL and parses the response into `out`.
// Returns 0 on success, negative SCE error code (or -1) on failure.
// `err_msg` receives a short human-readable reason on failure.
int api_fetch_comps(CompList *out, char *err_msg, int err_msg_len);

#endif // API_H
