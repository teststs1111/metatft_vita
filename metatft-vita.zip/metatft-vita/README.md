# MetaTFT Vita

A lightweight PS Vita homebrew client that fetches TFT comp/build data
as JSON and displays it in a native, controller-navigable UI (instead
of trying to render the actual metatft.com webpage, which isn't
practical on Vita — see "Why not just show the website" below).

This repo is a complete, ready-to-build source tree. **I couldn't
compile it to a `.vpk` in this environment** because that requires the
VitaSDK cross-toolchain (ARM GCC + Vita libraries), which isn't
installed here and isn't something I can install through this
sandbox's restricted network. You'll need to build it yourself — it's
about a 15–20 minute one-time setup. Steps below.

## What's included

```
metatft-vita/
├── CMakeLists.txt        # VitaSDK build script -> produces metatft_vita.vpk
├── include/
│   ├── api.h
│   └── config.h          # <-- put your API URL / key here
├── src/
│   ├── main.c            # vita2d UI: list view + detail view
│   ├── api.c             # SceHttp/SceSsl fetch + cJSON parse
│   └── cJSON.c           # vendored JSON library (MIT, DaveGamble/cJSON)
├── include/cJSON.h
└── sce_sys/
    └── icon0.png          # placeholder app icon, replace if you like
```

## 1. Set up VitaSDK (one-time, on your own PC)

```bash
# Linux/macOS
git clone https://github.com/vitasdk/vdpm
cd vdpm
export VITASDK=/usr/local/vitasdk
export PATH=$VITASDK/bin:$PATH
./bootstrap-vitasdk.sh
./install-all.sh
```

Also install `vita2d` (not always in the default package set):

```bash
vdpm vita2d
```

Windows: easiest path is WSL2 + the Linux instructions above.

## 2. Fill in your data source

Open `include/config.h` and set `API_BASE_URL` (and `API_KEY_HEADER` /
`API_KEY_VALUE` if your source needs auth). MetaTFT itself doesn't
publish an official public API, so realistically you have two options
— pick one before building:

- **A third-party proxy API** that re-serves MetaTFT-style comp data
  as JSON (a few exist; search "MetaTFT API"). Use for personal/testing
  use only, and check its terms.
- **Your own tiny backend** (a Cloudflare Worker / Vercel function you
  write) that fetches MetaTFT data server-side, caches it (e.g. every
  15–30 min), and re-serves plain JSON. This is the more robust option:
  you control caching and rate limits, and the Vita never talks to
  MetaTFT directly.

Either way, the JSON shape the app expects is documented at the top of
`config.h`. If your source returns different field names, adjust the
parsing in `src/api.c` (`parse_comps_json`) to match — it's about 15
lines.

**Please keep this to personal use.** MetaTFT's data is provided for
use through their own site/app; treat any API you point this at the
same way — light polling, no redistribution, no commercial use.

## 3. Build

```bash
export VITASDK=/usr/local/vitasdk
export PATH=$VITASDK/bin:$PATH

mkdir build && cd build
cmake ..
make
```

This produces `metatft_vita.vpk` in the `build/` directory.

## 4. Install on your Vita

1. Copy `metatft_vita.vpk` to your Vita (FTP via VitaShell, or a USB
   cable with `ux0:` mounted).
2. On the Vita, open **VitaShell**, navigate to the file, press
   **X**, choose **Install**.
3. Launch "MetaTFT Vita" from LiveArea.
4. Make sure Wi-Fi is connected before launching — it fetches data on
   startup.

## Controls

| Button        | Action                          |
|---------------|----------------------------------|
| ▲ / ▼         | Move selection in the list       |
| X             | Open detail view for selected comp |
| O             | Back to list                     |
| SELECT        | Refresh data                     |
| START         | Quit                             |

## Why not just show the website?

There's no maintained WebKit/Chromium port for Vita homebrew capable
of rendering a modern JS-heavy site like metatft.com, and building one
is a multi-year undertaking, not a weekend project. A native app that
fetches the underlying data and renders it with `vita2d` is the
practical way to get "MetaTFT on Vita" — faster, lighter on the
Vita's limited RAM, and works over slow Wi-Fi.

## Extending it

Ideas if you want to keep going:
- Add item/augment tier lists as a second tab (SELECT to cycle tabs)
- Cache the last successful fetch to `ux0:data/metatft_vita/cache.json`
  so the app still shows something offline
- Add a settings screen to change rank filter (Challenger/GM/Master/...)
  and POST that as a query param
- Swap the placeholder `sce_sys/icon0.png` / add a `livearea` folder
  for a nicer LiveArea tile

## Testing without a real Vita

[Vita3K](https://vita3k.org/) can run homebrew `.vpk`s on PC for quick
iteration before pushing to hardware, though HTTP/network emulation
support varies by build — real hardware is more reliable for testing
the networking parts.
